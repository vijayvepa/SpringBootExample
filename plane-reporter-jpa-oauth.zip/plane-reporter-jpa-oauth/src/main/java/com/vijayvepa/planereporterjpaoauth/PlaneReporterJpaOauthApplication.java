package com.vijayvepa.planereporterjpaoauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaneReporterJpaOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaneReporterJpaOauthApplication.class, args);
	}

}
