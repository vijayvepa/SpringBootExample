package com.vijayvepa.planereporterjpaoauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlaneReporterJpaOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
