package com.vijayvepa.planereportermvcstream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlaneReporterMvcStreamApplicationTests {

	@Test
	void contextLoads() {
	}

}
